<?php

$conn=new mysqli('localhost','admin','your_password','demo');
if($conn->connect_error)
{
	die("Connection Error".$conn->connect_error);
}

session_start();

include "db_conn.php";
include "config.php";

$username=$_GET['username'];
$password=$_GET['password'];
$sql="SELECT * FROM loginform WHERE user='$username' AND pass='$password'";
$result=$conn->query($sql);

if($result->num_rows>0)
{
        $userrow=mysqli_fetch_array($result);
	$token=uniqid(10);
        $checktoken = "SELECT COUNT(*) FROM `loginform_token` WHERE user='$username' and status=1";
        $_SESSION['token']=$token;
        $_SESSION['userid']=$username;
        if($row=$result->fetch_assoc($checktoken))
        {
		mysqli_query($con,"UPDATE `loginform_token` SET status=0 WHERE user='$username'");
	}
	else
	{
		mysqli_query($con,"INSERT INTO `loginform_token` VALUES (DEFAULT, '$username', '$token', 1)");
	}
        header("location: http://192.168.0.154/Sensorproject/sensordata.html");
}
else
	echo "Invalid Credentials";

?>
